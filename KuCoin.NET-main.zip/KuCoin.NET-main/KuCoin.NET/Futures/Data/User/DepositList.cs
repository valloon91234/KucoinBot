﻿using KuCoin.NET.Data;

using Newtonsoft.Json;

using System;
using System.Collections.Generic;
using System.Text;

namespace KuCoin.NET.Futures.Data.User
{
    public class DepositList : PaginatedData<Deposit>
    {

    }
}
